var commando = require('discord.js-commando');

class commandlist extends commando.Command {
    constructor(client) {
        super(client, {
            name: 'commandlist',
            group: 'other',
            memberName: 'commandlist',
            description: 'lists all the commands'
        });
    }
async run(message, args){
    message.reply("Commands: 1) Nicolon | 2) steam 3) oof | 4) rip | 5) Diamel | 6) bestship");
}

}
module.exports = commandlist;