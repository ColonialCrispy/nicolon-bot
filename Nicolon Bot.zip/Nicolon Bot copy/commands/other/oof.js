var commando = require('discord.js-commando');

class oof extends commando.Command {
    constructor(client) {
        super(client, {
            name: 'oof',
            group: 'other',
            memberName: 'oof',
            description: 'OOFA LOOFA OOF A DOO DOOF'
        });
    }
async run(message, args){
    message.reply("OOFA LOOFA OOF A DOO DOOF");
}

}
module.exports = oof;