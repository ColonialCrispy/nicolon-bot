var commando = require('discord.js-commando');

class rip extends commando.Command {
    constructor(client) {
        super(client, {
            name: 'rip',
            group: 'other',
            memberName: 'rip',
            description: 'Rip Liam Sales'
        });
    }
async run(message, args){
    message.reply(" RIP WONDER https://cdn.discordapp.com/attachments/367390736846684160/439955843937468436/unknown.png");
}

}
module.exports = rip;