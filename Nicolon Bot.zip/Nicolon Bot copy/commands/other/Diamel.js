var commando = require('discord.js-commando');

class diamel extends commando.Command {
    constructor(client) {
        super(client, {
            name: 'diamel',
            group: 'other',
            memberName: 'diamel',
            description: 'Diamel IRL according to his deviant art page.'
        });
    }
async run(message, args){
    message.reply("https://cdn.discordapp.com/attachments/367390736846684160/439955296367149056/unknown.png");
}

}
module.exports = diamel;