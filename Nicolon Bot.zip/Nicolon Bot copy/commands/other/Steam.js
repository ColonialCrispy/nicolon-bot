var commando = require('discord.js-commando');

class steam extends commando.Command {
    constructor(client) {
        super(client, {
            name: 'steam',
            group: 'other',
            memberName: 'steam',
            description: 'its pretty steamy in here'
        });
    }
async run(message, args){
    message.reply(" *it's pretty steamy in here my amigos* https://cdn.discordapp.com/attachments/367390736846684160/439956279822123038/unknown.png");
}

}
module.exports = steam;