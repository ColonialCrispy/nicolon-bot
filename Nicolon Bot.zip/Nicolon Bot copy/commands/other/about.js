var commando = require('discord.js-commando');

class about extends commando.Command {
    constructor(client) {
        super(client, {
            name: 'about',
            group: 'other',
            memberName: 'about',
            description: 'SEYX BOT'
        });
    }
async run(message, args){
    message.reply("NICOLON >.<");
}

}
module.exports = about;