var commando = require('discord.js-commando');

class woke extends commando.Command {
    constructor(client) {
        super(client, {
            name: 'woke',
            group: 'other',
            memberName: 'woke',
            description: '***WOKE ME UP <33333***'
        });
    }
async run(message, args){
    message.reply("https://cdn.discordapp.com/attachments/436165334496575490/439962986795368458/Screen_Shot_2018-04-28_at_8.35.34_PM.png");
}

}
module.exports = woke;