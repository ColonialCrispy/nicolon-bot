var commando = require('discord.js-commando');

class bestship extends commando.Command {
    constructor(client) {
        super(client, {
            name: 'bestship',
            group: 'other',
            memberName: 'bestship',
            description: 'best ship ever.'
        });
    }
async run(message, args){
    message.reply("https://cdn.discordapp.com/attachments/439555626381606915/439948949441216522/colonialxsap.png");
}

}
module.exports = bestship;