var commando = require('discord.js-commando');

class nicolon extends commando.Command {
    constructor(client) {
        super(client, {
            name: 'nicolon',
            group: 'other',
            memberName: 'nicolon',
            description: 'Nicolon!'
        });
    }
async run(message, args){
    message.reply("SUPPPERRRR NICOLONNNNNNN");
}

}
module.exports = nicolon;