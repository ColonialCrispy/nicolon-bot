var commando = require("discord.js-commando");
var yourbot = new commando.Client();

yourbot.login('NDA5ODE3MTQ5MTU5MjQzNzg2.Dcah-Q.WwrMUvPe8zFsulKeK2iDzxLxwZs');

yourbot.registry.registerGroup('other', 'Other');
yourbot.registry.registerCommandsIn(__dirname + "/commands")
yourbot.registry.registerDefaults();
