# BasicDiscordBot

Thanks For Downloading My Basic Discord Bot For Mac!

# Requirements

• Atom/Visual Studio Code
• Node.JS

# Setup

• Open Terminal.
• Type in: npm install discord.js-commando --save
• Then type in: npm install discord.js --save
• Those steps only need to be done once.

# Installations

• In the bot file, open up index.js and replace "YOUR_BOT_TOKEN_HERE" with your bot token. DO NOT REMOVE THE ""
• Restart Terminal.
• Type in cd (drag file in) and click enter. DO NOT ADD THE (drag file in). Instead drag your bot file in.
• Click Enter
• Type in: node .
• If nothing pops up, you are ready to go. Your bot should be online. 

# Commands

• !about
• !help
• !ping 
• !enable
• !disable

# Credits

Credits to Youtuber Joshman_ : https://www.youtube.com/channel/UCAZqoIHh2CFhcl9ZQLQXn7Q
His video: https://www.youtube.com/watch?v=0-Ee59jp_-Q&t=180s
